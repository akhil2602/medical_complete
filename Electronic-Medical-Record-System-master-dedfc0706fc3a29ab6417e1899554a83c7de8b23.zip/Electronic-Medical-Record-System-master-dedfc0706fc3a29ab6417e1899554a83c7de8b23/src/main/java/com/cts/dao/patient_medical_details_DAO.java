package com.cts.dao;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.cts.model.patient;
import com.cts.model.patient_medical;


public interface patient_medical_details_DAO {
	
	public List<patient_medical> getPatients_medical();

	public void savePatient_medical(patient_medical thePatientmedical);

	public patient_medical getPatient_medical(int theId);

	public patient_medical getSearch(int theId);
	
	public void updatePatientMedical(int id, String checkin_date, String checkout_date, String treatment_status,
			String doctor_name, String height, String weight, String blood_group, String bed_no);

	public List<patient_medical> getSearchPatient(int theId);
}
