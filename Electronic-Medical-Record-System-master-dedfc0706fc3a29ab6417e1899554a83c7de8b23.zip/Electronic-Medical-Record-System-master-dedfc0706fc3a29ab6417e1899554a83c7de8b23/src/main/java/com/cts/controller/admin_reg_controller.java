package com.cts.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.cts.model.admin;
import com.cts.model.customer;
import com.cts.model.patient;
import com.cts.model.patient_medical;
import com.cts.service.admin_reg_service;
import com.cts.service.patient_medical_details_service;
import com.cts.service.patient_reg_service;


@Controller 
@RequestMapping("/medical")
public class admin_reg_controller {
	@Autowired
	admin_reg_service  adminRegService;
	@Autowired
	patient_medical_details_service  patientMedicalDetailsService;
	@Autowired
	patient_reg_service  patientRegService;
	@GetMapping("/list")
	
	public String listadminReg(Model theModel){
		
		List<admin> theadmins=adminRegService.getAdmins();
		theModel.addAttribute("admin", theadmins);
	   return "list-admins";
		//return "demo";
		
	}
	
	
public String listpatientReg(Model theModel){
		
		List<patient> thepatients=patientRegService.getPatients();
		theModel.addAttribute("patient", thepatients);
	   return "list-patients";
		//return "demo";
		
	}

@GetMapping("/listPatient")
public String listpatientMedicalDetails(Model theModel){
	
	List<patient_medical> thepatientsMedical=patientMedicalDetailsService.getPatients_medical();
	theModel.addAttribute("patient_medical", thepatientsMedical);
   return "patient_history";
	//return "demo";
	
}
	
	@GetMapping("/showForm")
	public String showFormForAdd(Model theModel){
		admin theAdmin=new admin();
		theModel.addAttribute("admin", theAdmin);
		return "admin_register";
		
	}
	
	
	@GetMapping("/showForm1")
	public String showFormForAdd1(Model theModel){
		patient thePatient=new patient();
		theModel.addAttribute("patient", thePatient);
		return "patient_personal_details";
		
	}
	
	
	@GetMapping("/showForm2")
	public String showFormForAdd2(Model theModel){
		patient_medical thePatientMedical=new patient_medical();
		theModel.addAttribute("patient_medical", thePatientMedical);
		return "patient_medical_details";
		
	}
	@PostMapping("/saveAdmin")
	public String saveAdmin(@ModelAttribute("admin") admin theAdmin){
		adminRegService.saveAdmin(theAdmin);
		return "admin_homepage";
	}
	
	@PostMapping("/savePatient")
	public String savePatient(@ModelAttribute("patient") patient thePatient){
		patientRegService.savePatient(thePatient);
		return "patient_medical_details";
	}
	
	@PostMapping("/savePatient_medical")
	public String savePatient_medical(@ModelAttribute("patient_medical") patient_medical thePatientmedical){
		patientMedicalDetailsService.savePatient_medical(thePatientmedical);
		return "admin_homepage";
	}
	
	@GetMapping("/showLogin")
	public String showlogin()
	{
		//admin theAdmin=new admin();
		//theModel.addAttribute("admin", theAdmin);
		return "adminlogin";
	}
	
	@GetMapping("/login")
public String loginAdmin(@RequestParam("idd") int theId, @RequestParam("em") String em,Model theModel){
		
		admin theadmin=adminRegService.getLogin(theId,em);
		theModel.addAttribute("admin",theadmin);
		
		
		
		if(theadmin==null){
			return "invalid";
		}
		return "admin_homepage";
		
	}
	
	
	@GetMapping("/patientlogin")
	public String loginPatient(@RequestParam("idd") int theId, @RequestParam("em") String em,Model theModel){
			
			patient thepatient=patientRegService.getLogin(theId,em);
			theModel.addAttribute("patient",thepatient);
			
			if(thepatient==null){
				return "invalid_patient";
			}
			return "reset_password";
	}
	
	
	@GetMapping("/showLogin1")
	public String showlogin1()
	{
		//admin theAdmin=new admin();
		//theModel.addAttribute("admin", theAdmin);
		return "patient_login";
	}
	
	
	
	
	
	//search patient personal details
	@GetMapping("/search")
	public String searchPatient(@RequestParam("idd") int theId,Model theModel){
			
			patient thepatient=patientRegService.getSearch(theId);
			theModel.addAttribute("patient",thepatient);
			return "display_search_personal";
	}
	
	//isko thik karna hai    //patient medical search
	@GetMapping("/search1")
	public String searchPatient1(@RequestParam("idd") int theId,Model theModel){
			
			patient_medical thepatient=patientMedicalDetailsService.getSearch(theId);
			theModel.addAttribute("patient_medical",thepatient);
			return "display_search_medical";
	}
	
	
	@GetMapping("/history")
	public String historyMedical(@RequestParam("idd") int theId,Model theModel){
			
			List<patient_medical> thepatient=patientMedicalDetailsService.getSearchPatient(theId);
			theModel.addAttribute("patient_medical",thepatient);
			return "patient_history";
	}
	
	//update Personal Details
	@GetMapping("/updatePersonalDetails")
	public String showFormForUpdate(@RequestParam("user_id") int theId,@RequestParam("aadhar_no") String aadhar_no,@RequestParam("address") String address,@RequestParam("m_no") String m_no,@RequestParam("patient_name") String patient_name,Model theModel){
		System.out.println("update");
		patient thePatient=patientRegService.getPatient(theId);
		System.out.println("akhil");
		theModel.addAttribute("patient", thePatient);
		patientRegService.updatePatient(theId,aadhar_no,address,m_no,patient_name);
		return"update_page";
	}
	
	
	
	@GetMapping("/updatePersonalDetailsPatient")
	public String showFormForUpdatePatient(@RequestParam("user_id") int theId,@RequestParam("aadhar_no") String aadhar_no,@RequestParam("address") String address,@RequestParam("m_no") String m_no,@RequestParam("patient_name") String patient_name,Model theModel){
		System.out.println("update");
		patient thePatient=patientRegService.getPatient(theId);
		System.out.println("akhil");
		theModel.addAttribute("patient", thePatient);
		patientRegService.updatePatient(theId,aadhar_no,address,m_no,patient_name);
		return"patient_homepage";
	}
	
	
	
	
	
	//update password
	@GetMapping("/updatePassword")
	public String showFormForPasswordUpdate(@RequestParam("user_id") int theId,@RequestParam("password") String password,Model theModel){
		
		patient thePatient=patientRegService.getPatient(theId);
		
		theModel.addAttribute("patient", thePatient);
		patientRegService.updatePassword(theId,password);
		return"patient_homepage";
	}
	
	/*//update Personal Details
		@GetMapping("/updatePersonalDetails")
		public String showFormForUpdate(@RequestParam("id") int theId,@RequestParam("aadhar_no") String aadhar_no,@RequestParam("address") int address,@RequestParam("m_no") int m_no,@RequestParam("patient_name") int patient_name,Model theModel){
			System.out.println("update");
			patient thePatient=patientRegService.getPatient(theId);
			System.out.println("akhil");
			theModel.addAttribute("patient", thePatient);
			patientRegService.updatePatient(theId,aadhar_no,address,m_no,patient_name);
			return"patient_personal_details_update";
		}*/
	
	
	
	
	
	@GetMapping("/updateMedicalDetails")
	public String showFormForUpdate(@RequestParam("user_id") int theId,@RequestParam("checkin_date") String checkin_date,@RequestParam("checkout_date") String checkout_date,@RequestParam("treatment_status") String treatment_status,@RequestParam("doctor_name") String doctor_name,@RequestParam("height") String height,@RequestParam("weight") String weight,@RequestParam("blood_group") String blood_group,@RequestParam("bed_no") String bed_no,Model theModel){
		System.out.println("update");
		patient_medical thePatient=patientMedicalDetailsService.getPatient_medical(theId);
		System.out.println("akhil");
		theModel.addAttribute("patient_medical", thePatient);
		patientMedicalDetailsService.updatePatientMedical(theId,checkin_date,checkout_date,treatment_status,doctor_name,height,weight,blood_group,bed_no);
		return"update_page";
	}
	
	
	
	
	
	@GetMapping("/show12")
	public String showFormForAdd12(Model theModel){
		patient thePatient=new patient();
		theModel.addAttribute("patient", thePatient);
		return "update-form";
		
	}
	
	@GetMapping("/show123")
	public String showFormForAdd123(Model theModel){
		patient_medical thePatient=new patient_medical();
		theModel.addAttribute("patient_medical", thePatient);
		return "update-medical-form";
		
	}
	
	
	@GetMapping("/showSearchMedical")
	public String showSearchMedical()
	{
		
		return "search_medical";
	}
	
	@GetMapping("/showSearchPersonal")
	public String showSearchPersonal()
	{
		
		return "search_personal";
	}
	
	
	@GetMapping("/showPage")
	public String showPage()
	{
		
		return "search_page";
	}
	
	
	@GetMapping("/showUpdate")
	public String showUpdate()
	{
		
		return "update_page";
	}
	
	@GetMapping("/showUpdatePersonal")
	public String showUpdatePersonal()
	{
		
		return "update-form";
	}
	
	@GetMapping("/showUpdatePersonalPatient")
	public String showUpdatePersonalPatient()
	{
		
		return "update-form-patient";
	}
	
	
	@GetMapping("/patientHomepage")
	public String patientHomepage()
	{
		
		return "patient_homepage";
	}

	
	@GetMapping("/history_id")
	public String history_id()
	{
		
		return "show_id";
	}

}
