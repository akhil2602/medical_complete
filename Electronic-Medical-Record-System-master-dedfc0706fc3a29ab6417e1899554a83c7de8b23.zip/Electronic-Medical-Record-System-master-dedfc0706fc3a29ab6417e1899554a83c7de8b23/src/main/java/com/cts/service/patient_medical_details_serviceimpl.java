package com.cts.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.cts.dao.patient_medical_details_DAO;
import com.cts.model.patient;
import com.cts.model.patient_medical;

@Service("patient_medical_details_service")
public class patient_medical_details_serviceimpl implements patient_medical_details_service {
	@Autowired
	patient_medical_details_DAO c;
	@Transactional
	public List<patient_medical> getPatients_medical() {
		// TODO Auto-generated method stub
		return c.getPatients_medical();
	}

	
		
	//}
	@Transactional
	public patient_medical getPatient_medical(int theId) {
		// TODO Auto-generated method stub
		return c.getPatient_medical(theId);
	}
	@Transactional
	public void savePatient_medical(patient_medical thePatientmedical) {
		// TODO Auto-generated method stub
		c.savePatient_medical(thePatientmedical);
	}

	@Transactional
	public patient_medical getSearch(int theId)
	{
		return c.getSearch(theId);
	}


	@Transactional
	public void updatePatientMedical(int id, String checkin_date, String checkout_date, String treatment_status,
			String doctor_name, String height, String weight, String blood_group, String bed_no) {
		// TODO Auto-generated method stub
		c.updatePatientMedical(id, checkin_date, checkout_date, treatment_status, doctor_name, height, weight, blood_group, bed_no);
	}


	@Transactional
	public List<patient_medical> getSearchPatient(int theId) {
		// TODO Auto-generated method stub
		return c.getSearchPatient(theId);
	}

	
		
	
	
	
	

}
