package com.cts.service;

import java.util.List;

import com.cts.model.admin;
import com.cts.model.customer;

public interface admin_reg_service {
	public List<admin> getAdmins();

	public void saveAdmin(admin theAdmin);

	public admin getAdmin(int theId);
	
	public admin getLogin(int theId,String em);

	
}
