package com.cts.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.cts.dao.admin_reg_DAO;
import com.cts.dao.patient_reg_DAO;
import com.cts.model.patient;
@Service("patient_reg_service")
public class patient_reg_serviceimpl implements patient_reg_service {

	@Autowired
	patient_reg_DAO c;	
	@Transactional
	public List<patient> getPatients() {
		// TODO Auto-generated method stub
		return c.getPatients();
	}
	@Transactional
	public void savePatient(patient thePatient) {
		// TODO Auto-generated method stub
		c.savePatient(thePatient);
	}
	@Transactional
	public patient getPatient(int theId) {
		// TODO Auto-generated method stub
		return c.getPatient(theId);
	}
	@Transactional
	public patient getLogin(int theId, String em) {
		
	
	
		return c.getLogin(theId,em);
		
	}
	@Transactional
	public patient getSearch(int theId)
	{
		return c.getSearch(theId);
	}
	
	@Transactional
	public void updatePatient(int id, String aadhar_no, String address, String m_no, String patient_name) {
		// TODO Auto-generated method stubc
		c.updatePatient(id,aadhar_no,address,m_no,patient_name);
		
	}
	
	@Transactional
	public void updatePassword(int theId, String password) {
		// TODO Auto-generated method stub
		c.updatePassword(theId,password);
		
	}
	
	
	
	
	
}
