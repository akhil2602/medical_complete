package com.cts.service;

import java.util.List;

import com.cts.model.admin;
import com.cts.model.patient;

public interface patient_reg_service {
	
	
	public List<patient> getPatients();

	public void savePatient(patient thePatient);

	public patient getPatient(int theId);
	
	public patient getLogin(int theId, String em);

	public patient getSearch(int theId);

	public void updatePatient(int theId, String aadhar_no, String address, String m_no, String patient_name);

	public void updatePassword(int theId, String password);

	
}
