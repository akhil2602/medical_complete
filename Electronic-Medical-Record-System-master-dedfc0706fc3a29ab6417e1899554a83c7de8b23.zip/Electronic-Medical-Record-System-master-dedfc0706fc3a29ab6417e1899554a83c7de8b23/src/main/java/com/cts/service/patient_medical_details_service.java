package com.cts.service;

import java.util.List;

import com.cts.model.patient;
import com.cts.model.patient_medical;

public interface patient_medical_details_service {
	
	public List<patient_medical> getPatients_medical();

	public void savePatient_medical(patient_medical thePatientmedical);

	public patient_medical getPatient_medical(int theId);

	public patient_medical getSearch(int theId);

	public void updatePatientMedical(int theId, String checkin_date, String checkout_date, String treatment_status,
			String doctor_name, String height, String weight, String blood_group, String bed_no);

	public List<patient_medical> getSearchPatient(int theId);

}
